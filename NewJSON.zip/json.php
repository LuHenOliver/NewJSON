<?php

$arquivo = "dados.json";

$senhaOk = md5("senha");
$cpf    = $_REQUEST["cpf"];
$senha  = $_REQUEST["senha"];
$senha  = MD5($senha);

$dados = [
    'cpf' => $cpf,
    'senha' => $senha
];

if( file_exists($arquivo) and $senha == $senhaOk){
    $dadosLidos = file_get_contents($arquivo);
    $existente  = json_decode($dadosLidos, true);
    header("Location: menu.html");
    exit();

    
}
else 
{
    $json = json_encode($dados); 
    file_put_contents($arquivo, $json); 
    header("location: form.html");
}


?>